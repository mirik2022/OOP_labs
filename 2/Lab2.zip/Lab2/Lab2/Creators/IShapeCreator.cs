﻿using System.Drawing;

namespace Lab2
{
    // Interface for creating shapes
    // Each shape type has its own creator class
    public interface IShapeCreator
    {
        // Returns display name for the shape in UI
        string GetName();

        // Creates a shape based on two mouse click points
        Shape Create(Point start, Point end);
    }
}