﻿using System.Drawing;

namespace Lab2
{
    /// Interface for shape drawers
    /// Each shape type has its own drawer class
    public interface IShapeDrawer
    {
        void Draw(Shape shape, Graphics g);
    }
}