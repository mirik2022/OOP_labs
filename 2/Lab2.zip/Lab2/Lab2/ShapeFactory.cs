﻿using System;

namespace Lab2
{
    /// Factory class that creates shapes
    /// To add a new shape, just add its creator to the array
    public class ShapeFactory
    {
        private IShapeCreator[] creators;

        public ShapeFactory()
        {
            // Initialize all available shape creators
            // Adding a new shape only requires adding one line here
            creators = new IShapeCreator[]
            {
                new LineCreator(),
                new RectangleCreator(),
                new SquareCreator(),
                new EllipseCreator(),
                new CircleCreator(),
                new TriangleCreator()
            };
        }

        // Get all shape names for the dropdown menu
        public string[] GetAllNames()
        {
            string[] names = new string[creators.Length];
            for (int i = 0; i < creators.Length; i++)
            {
                names[i] = creators[i].GetName();
            }
            return names;
        }

        // Create a shape by name using two points
        public Shape CreateShape(string name, Point start, Point end)
        {
            for (int i = 0; i < creators.Length; i++)
            {
                if (creators[i].GetName() == name)
                {
                    return creators[i].Create(start, end);
                }
            }
            return null;
        }
    }
}