﻿using System.Collections.Generic;
using System.Drawing;

namespace Lab2
{
    /// Container class for storing and managing all drawn shapes
    /// Uses separate drawers for rendering
    public class ShapeList
    {
        private List<Shape> shapes = new List<Shape>();
        private DrawerFactory drawerFactory = new DrawerFactory();

        public void Add(Shape shape)
        {
            shapes.Add(shape);
        }

        public void Clear()
        {
            shapes.Clear();
        }

        /// Draw all shapes using their respective drawers
        public void DrawAll(Graphics g)
        {
            foreach (Shape shape in shapes)
            {
                IShapeDrawer drawer = drawerFactory.GetDrawer(shape);
                if (drawer != null)
                {
                    drawer.Draw(shape, g);
                }
            }
        }
    }
}