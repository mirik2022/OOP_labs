﻿using System.Drawing;

namespace Lab2
{
    /// <summary>
    /// Abstract base class for all geometric shapes
    /// Note: Shape classes do NOT contain drawing methods
    /// </summary>
    public abstract class Shape
    {
        public string Name { get; protected set; }
        public Color Color { get; set; } = Color.Black;
    }
}